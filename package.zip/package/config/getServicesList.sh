#!/bin/bash

v_INFACMDPATH=$1 
v_DOMAIN=$2
v_USERNAME=$3
v_PASSWORD=$4
v_OUTPUTFILE=$5


cd $v_INFACMDPATH

echo "Starting infacmd..." > $v_OUTPUTFILE

for s in "AS" "CMSA" "RS" 
 do 
   echo $s service details : START >> $v_OUTPUTFILE
   infacmd.sh isp ListServices -dn $v_DOMAIN -un $v_USERNAME -pd $v_PASSWORD -st $s >> $v_OUTPUTFILE
   echo $s service details : END >> $v_OUTPUTFILE
 done

