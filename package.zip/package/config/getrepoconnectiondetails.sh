#!/bin/bash

v_PMREPPATH=$1
v_REPO=$2
v_DOMAIN=$3
v_USERNAME=$4
v_PASSWORD=$5
v_OUTPUTFILE=$6

cd $v_PMREPPATH

pmrep connect -r $v_REPO -d $v_DOMAIN -n $v_USERNAME -x $v_PASSWORD

pmrep listconnections -t > $v_OUTPUTFILE

