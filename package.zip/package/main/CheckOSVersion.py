#######################################################
#### Script to check the OS , version compatibility
#### Date : 20 March 2024
########################################################
import platform
import sys
import config
import re
import subprocess

def checkosversion(v_report_folder):
    version_is_compatible = False
    os_is_compatible = False

    if platform.system() in 'Windows':
        v_OSVERSION_folder = v_report_folder + '\\report'

        filename_op = v_OSVERSION_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'w+')

    if platform.system() in 'Linux':
        v_OSVERSION_folder = v_report_folder + '//report'

        filename_op = v_OSVERSION_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'w+')

    my_file.write("Check #1 - OS Compatibility :\n\n")

    if platform.system() in 'Windows':
        build=str(sys.getwindowsversion().build)
        d_windows_supported_version_name = {'14393': 'Windows 10 version 1607', '16299': 'Windows 10 version 1709', '17134': 'Windows 10 version 1803', '17763': 'Windows 10 version 1809', '18362': 'Windows 10 version 1903', '18363': 'Windows 10 version 1909', '19041': 'Windows 10 version 2004', '19042': 'Windows 10 version 20H2', '20348': 'Windows Server 2022', '19045': 'Windows 10 version 22H2'}
        for versionnumber in config.windows_supported_version:
            version_is_compatible = bool(re.search(versionnumber, build))
            windows_supported_version_name = d_windows_supported_version_name.get(build)
            if version_is_compatible:
                print(f"Windows version is compatible : {windows_supported_version_name}, Build : {build}")
                my_file.write(f"Windows version is compatible : {windows_supported_version_name}, Build : {build}\n\n")
                break
    elif platform.system() in 'Linux':
        version_details = str(subprocess.check_output('cat /etc/os-release | grep -i version_id', shell=True))
        os_details = str(subprocess.check_output('cat /etc/os-release | grep -i pretty_name', shell=True))
        version_is_compatible = False
        os_is_compatible = False
        for versionnumber in config.rhel_supported_version:
            if (bool(re.search(versionnumber, version_details))) and (bool(re.search('Red Hat Enterprise Linux', os_details))):
                print(f"Rhel version is compatible : {version_details},{os_details}")
                my_file.write(f"Rhel version is compatible : {version_details},{os_details}\n\n")
                version_is_compatible = True

        for versionnumber in config.suse_linux_version:
            if (bool(re.search(versionnumber, version_details))) and (bool(re.search('SUSE Linux', os_details))):
                print(f"SUSE Linux version is compatible : {version_details},{os_details}")
                my_file.write(f"SUSE Linux version is compatible : {version_details},{os_details}\n\n")
                version_is_compatible = True

        for versionnumber in config.suse_linux_version:
            if (bool(re.search(versionnumber, version_details))) and (bool(re.search('Amazon Linux', os_details))):
                print(f"Amazon Linux version is compatible : {version_details},{os_details}")
                my_file.write(f"Amazon Linux version is compatible : {version_details},{os_details}\n\n")
                version_is_compatible = True

    if not(version_is_compatible):
        print("OS Version - unsupported")
        my_file.write("OS Version - unsupported\n\n")

    my_file.close()

if __name__ == '__main__':
    checkosversion(v_report_folder)

