import oracledb
import re
import config
import platform

def check_oracle_version(v_report_folder):
    if platform.system() in 'Windows':
        v_Oracle_error_folder = v_report_folder + '\\report'
        filename_op = v_Oracle_error_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    if platform.system() in 'Linux':
        v_Oracle_error_folder = v_report_folder + '//report'
        filename_op = v_Oracle_error_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    my_file.write("Check #2 - DB Compatibility :\n\n")

    v_max_login_attempts = 2
    counter = 0
    while True:
        if counter == v_max_login_attempts:
            print("Attempts exhausted, please try after sometime...")
            break

        remaining_attempts = v_max_login_attempts - counter

        print(f'Please enter the DB details (Attempts remaining : {remaining_attempts})...')

        username = input('Enter the username : ') # "PCREPO59"
        userpwd = input('Enter the password : ') # "PCREPO"
        host = input('Enter the host details : ') # "invrh7gcstst01.informatica.com"
        port = input('Enter the port number : ') # 1521
        service_name = input('Enter the service name : ') # "ORCL.informatica.com"

        counter = counter + 1

        '''
        # Hardcoded values
        username = "****"
        userpwd = "****"
        host = "*****"
        port = *****
        service_name = "******"
        '''

        try:
            dsn = f'{username}/{userpwd}@{host}:{port}/{service_name}'
            connection = oracledb.connect(dsn)

            cursor = connection.cursor()
            cursor.execute("SELECT * FROM V$VERSION where Banner like '%Oracle Database%'")
            row = cursor.fetchone()
            v_flag = 0
            for versionnumber in config.oracle_version:
                if bool(re.search(versionnumber, str(row))):
                    v_flag = 1
                    break
            if v_flag ==1:
                print(f"Supported DB version, version : {str(row)}")
                my_file.write(f"Supported DB version, version : {str(row)}\n\n")
            else :
                print(f"Un-Supported version, version : {str(row)}")
                my_file.write(f"Un-Supported version, version : {str(row)}\n\n")
            connection.close()
            break
        except Exception as error:
            print("Unable to update DB")
            print("Error:", error)
            my_file.write("Unable to update DB\n")
            my_file.write(f"Error message : {error}\n\n")

    my_file.close()

if __name__ == '__main__':
    check_oracle_version(v_report_folder)



