import os

# pc_infa_home='C:\\Informatica\\10.5.1'

def check_odbc_ini(report_folder,pc_infa_home):

    v_ODBCreport_folder = report_folder + '\\report'
    filename_op = v_ODBCreport_folder + '\\' + 'Output_Report_File.txt'
    my_file = open(filename_op, 'a+')

    my_file.write("Check #6 - ODBC file updates :\n\n")

    file_present_flag=False
    driver_present_flag=False
    odbc_ini_path = os.path.join(os.environ['SystemDrive'], '\\Windows', 'ODBC.INI')

    if os.path.isfile(odbc_ini_path):
        file_present_flag = True
        print(f"ODBC.INI file exist in the path {odbc_ini_path}")
        my_file.writelines(rf"The ODBC.INI is present in {odbc_ini_path}")
        my_file.writelines("\n")
        
    if file_present_flag == True:
        f1 = open(odbc_ini_path,"r")
        for iterator in f1:
            splt = None
            if iterator.find("Driver32=") == 0 or iterator.find("Driver64=") == 0:
                splt=iterator.split("=")
                if splt[1].find(pc_infa_home) >= 0:
                    driver_present_flag = True
        if driver_present_flag == True:
            print("Informatica drivers were used in the DSN. Please check and modify the DSN information post CDI-PC Migration")
            my_file.writelines(r"ODBC.INI file is using Informatica drivers present in $INFA_HOME\ODBC7.1")
        else:
            print("No Informatica drivers found in the DSN.")
            my_file.writelines(r"No ODBC DSNs are using Informatica drivers present in $INFA_HOME\ODBC7.1")
    else:
        print("ODBC.INI file does not exist and does not need modification post CDIPC migration")
        my_file.writelines("No ODBC.INI files found and does not need modification post CDIPC migration\n\n")
        print("Report is generated")

# Call the function to check odbc.ini