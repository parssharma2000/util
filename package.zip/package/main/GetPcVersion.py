import re
from config import Supported_PC_Version
import platform

# Define the pattern to match the version number
pattern=r'\[(\d+\.\d+(\.\d+)?)\]'

#pcfile = 'C:\\Users\\supsingh\\PycharmProjects\\PreReqUtility\\test1.txt'

def Read_PC_Versionfile(v_report_folder, pcfile):
    if platform.system() in 'Windows':
        v_OSVERSION_folder = v_report_folder + '\\report'

        filename_op = v_OSVERSION_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    if platform.system() in 'Windows':
        v_OSVERSION_folder = v_report_folder + '//report'

        filename_op = v_OSVERSION_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    my_file.write("Check #5 - PC Version Compatibility with CDI-PC :\n\n")

    with open(pcfile, 'r') as file:
        content = file.read()

    # Search for the pattern in the content
    match = re.search(pattern, content)
    # If a match is found, print the version number
    if match:
        version = match.group(1)
        print("\nCurrent Informatica Version : ", version)
        my_file.write(f"Current Informatica Version : {version}\n\n")
        if version in Supported_PC_Version:
            print(version, ' is supported for CDI-PC Migration')
            my_file.write(f"{version} is supported for CDI-PC Migration\n\n")
        else:
            print(version, ' is not supported for CDI-PC Migration')
            my_file.write(f"{version} is not supported for CDI-PC Migration\n\n")

    else:
        print("Version not found")
        my_file.write(f"Version not found\n\n")

    my_file.close()
