import os
import platform


def getfiledetails():
    directory = input('Please enter log directory details:')
    while True:
        if not os.path.exists(directory):
            directory = input("Path does not exist. Enter a valid path?")

        else:
            try:
                print("Path exists")
                filename_op = directory+'//CDIPC_PrereqUtility_OP.txt'
                filename_logs = directory + '//CDIPC_PrereqUtility_logs.txt'
                my_file = open(filename_op, 'w+')
                my_file.write('Test')
                my_file.close()
                my_file = open(filename_logs, 'w+')
                my_file.write('Test')
                my_file.close()
                print("test file created successfully")
                break
            except Exception as error:
                print("Unable to create file. Check the folder permission. Error:", error)
                pass
            break


def checkpath(filepath_absolute):
    while True:
        if not os.path.isdir(filepath_absolute):
            filepath_absolute = input("Path does not exist. Enter a valid path? ")
        else:
            # print("path exist")
            return filepath_absolute

def checksubpaths(filepath_absolute):
    while True:
        if platform.system() in 'Windows':
            v_config_folder = filepath_absolute + '\\config'
            v_logs_folder = filepath_absolute + '\\logs'
            v_report_folder = filepath_absolute + '\\report'
            v_pcversion_folder = v_config_folder + '\\getPCverison.bat'
            v_repoconn_folder = v_config_folder + '\\getrepoconnectiondetails.bat'
            v_repoconnsh_folder = v_config_folder + '\\getrepoconnectiondetails.sh'
            v_servicelist_folder = v_config_folder + '\\getServicesList.bat'
            v_isp_folder = v_config_folder + '\\ISPCommands1.bat'

        if platform.system() in 'Linux':
            v_config_folder = filepath_absolute + '//config'
            v_logs_folder = filepath_absolute + '//logs'
            v_report_folder = filepath_absolute + '//report'
            v_pcversion_folder = v_config_folder + '//getPCverison.bat'
            v_repoconn_folder = v_config_folder + '//getrepoconnectiondetails.bat'
            v_repoconnsh_folder = v_config_folder + '//getrepoconnectiondetails.sh'
            v_servicelist_folder = v_config_folder + '//getServicesList.bat'
            v_isp_folder = v_config_folder + '//ISPCommands1.bat'

        dirlst = [v_logs_folder, v_report_folder]
        filelst = [v_pcversion_folder, v_repoconn_folder, v_isp_folder, v_repoconnsh_folder, v_servicelist_folder]

        for i in dirlst:
            if not os.path.isdir(i):
                print(f"{i} path does not exist")
        for i in filelst:
            if not os.path.isfile(i):
                print(f"{i} file does not exist")
        else:
            return

def createfile(directory, filename):
    try:
        # print("Path exists")
        filename_op = directory + '\\' + filename
        print(filename_op)
        my_file = open(filename_op, 'w+')
        my_file.write('Test')
        my_file.close()
        print("Test file created successfully")
    except Exception as error:
        print("Unable to create file.Error:", error)
        print("exiting the program..please check the folder/file permission and retry")
        exit()

def checkfile(filepath_absolute):
    return os.path.isfile(filepath_absolute)

def checkdir(filepath_absolute):
    return os.path.isdir(filepath_absolute)

# checkpath("C:\\Informatica\\10.5.3Server\\server\\bin\\")
