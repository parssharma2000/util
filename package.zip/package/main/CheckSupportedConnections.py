from config import supported_relational_connections, supported_app_connections
import platform

def read_file_to_list(file_path, ignore_top, ignore_bottom):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
        lines = lines[ignore_top:len(lines) - ignore_bottom]
        lines = [line.strip() for line in lines]
        return lines
    except FileNotFoundError:
        print("\nFile not found")
        return None
    except Exception as e:
        print(f"\nAn error occurred : {e}")
        return None

def extract_lists_from_content(content_list):
    relational_list = []
    application_list = []
    other_list = []
    try:
        for line in content_list:
            parts = line.split(',')
            if len(parts) >= 2:
                if parts[1] == 'relational':
                    relational_list.append(parts)
                elif parts[1] == 'application':
                    application_list.append(parts)
                else:
                    other_list.append(parts)
        return relational_list, application_list, other_list
    except Exception as e:
        print(f"\nAn error occurred while processing content : {e}")
        return None, None, None

def get_connection_types_and_unsupported(connection_list, supported_connections):
    unsupported_types = {}
    try:
        for row in connection_list:
            if len(row) >= 3:
                connection_type = row[2]
                if connection_type not in supported_connections:
                    if connection_type not in unsupported_types:
                        unsupported_types[connection_type] = []
                    unsupported_types[connection_type].append(row[0])
        return unsupported_types
    except Exception as e:
        print(f"\nAn error occurred while processing connection types : {e}")
        return None

def process_file(configpath, reportpath):

    if platform.system() in 'Windows':
        v_connection_error_folder = configpath + '\\report'

        filename_op = v_connection_error_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    if platform.system() in 'Linux':
        v_connection_error_folder = configpath + '//report'

        filename_op = v_connection_error_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    my_file.write("Check #4 - Connections Compatibility with CDI-PC :\n\n")

    ignore_top = 11
    ignore_bottom = 3
    content_list = read_file_to_list(reportpath, ignore_top, ignore_bottom)

    if content_list:
        relational_list, application_list, other_list = extract_lists_from_content(content_list)

        unsupported_rel_types = {}
        unsupported_app_types = {}

        if relational_list:
            unsupported_rel_types = get_connection_types_and_unsupported(relational_list, supported_relational_connections)

        if application_list:
            unsupported_app_types = get_connection_types_and_unsupported(application_list, supported_app_connections)

        if unsupported_rel_types:
            print("\nPlease see the Unsupported Relational Connection Type and respective connections : ")
            my_file.write(f"Please see the Unsupported Relational Connection Type and respective connections : \n\n")
            print(unsupported_rel_types)
            my_file.write(f"{unsupported_rel_types}\n\n")
        else:
            print("\nNo unsupported relational connection found")
            my_file.write(f"No unsupported relational connection found\n\n")
        if unsupported_app_types:
            print("\nPlease see the Unsupported Application Connection Type and respective connections : ")
            my_file.write(f"Please see the Unsupported Application Connection Type and respective connections : \n\n")
            print(unsupported_app_types)
            my_file.write(f"{unsupported_app_types}\n\n")
        else:
            print("\nNo unsupported application connection found")
            my_file.write(f"No unsupported application connection found\n\n")
        dict_other_list = {}
        if other_list:
            for conn_type in other_list:
                if conn_type[1] not in dict_other_list:
                    dict_other_list[conn_type[1]] = [conn_type[0]]
                else:
                    dict_other_list[conn_type[1]].append(conn_type[0])

        # Print the dictionary representation of other_list
        if dict_other_list:
            print("\nPlease see the unknown connections which have to be checked : ")
            my_file.write(f"Please see the unknown connections which have to be checked : \n\n")
            print(dict_other_list)
            my_file.write(f"{dict_other_list}\n\n")
        else:
            print("\nNo Unknown connection types found")
            my_file.write(f"No Unknown connection types found\n\n")

    else:
        print("\nError occurred while reading the file")
        my_file.write(f"Error occurred while reading the file\n\n")


    print(f"\nPlease check the connectiondetails.txt at {reportpath} for the complete list of connections")
    my_file.write(f"Please check the connectiondetails.txt at {reportpath} for the complete list of connections\n\n")

    my_file.close()