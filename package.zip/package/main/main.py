import platform

from FileModule import checkpath, checksubpaths, createfile, checkfile, checkdir
import os, oracledb
from CheckOSVersion import checkosversion

from OracleModule import check_oracle_version
from PostGresModule import check_postgresql_version
from MSSQLServerModule import check_mssqlserver_version

from getServicesDetails import getservicelist
from ReadFileToGetServiceDetails import getservicedetailsfromfile

from getServicesDetails import getrepoconnection
from CheckSupportedConnections import process_file

from getServicesDetails import getPCVersion
from GetPcVersion import Read_PC_Versionfile

from ODBCiniCheck_windows import check_odbc_ini

from License_check import licensecheck


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print("Starting Pre-req utility ... ")
    while True:
        v_input = input("Press 1 for Domain, 2 for DMA : ")
        if v_input in ("1", "2"):
            break
        else:
            print("Please enter valid input\n")

    v_report_folder = input("Enter the path where you have placed the required 3 folders (config, logs, report) : ")
    v_report_folder = checkpath(v_report_folder)
    checksubpaths(v_report_folder)
    # createfile(v_report_folder,'CDIPC_PrereqUtility_OP.txt')

    if int(v_input) == 1:
        print("""\nBelow check to be performed : 
              1. OS Compatibility for CDI-PC
              2. DB Compatibility for CDI-PC
              3. Services available on the Domain
              4. Connections Compatibility with CDI-PC
              5. PC Version Compatibility with CDI-PC
              6. ODBC file updates\n""")

        while True:
            v_check = input("Select the check you want to make (1, 2, 3, 4, 5, 6 or all) : ")
            if v_check in ("1", "2", "3", "4", "5", "6", "all"):
                break
            else:
                print("Please enter valid input\n")

        v_infa_home = input("\nEnter INFA_HOME Details : ")
        v_repository = input("Repository name : ")
        v_domain = input("Domain name : ")
        v_adminusername = input("Infa Admin Username : ")
        v_adminpassword = input("Infa Admin Password : ")
        # v_adminpassword = getpass.getpass("Infa Admin Password : ")
        # print(v_adminpassword)

        if platform.system() in 'Windows':
            configpath = v_report_folder + '\\config'
            connectionreportpath = v_report_folder + '\\report\\connectiondetails.txt'
            servicereportpath = v_report_folder + '\\report\\serviceslist.txt'
            v_pmrep_path = v_infa_home + '\\server\\bin'
            v_isp_path = v_infa_home + '\\isp\\bin'
            v_pcversionoutputfile = v_report_folder + '\\report\\PcVersionDetails.txt'

        if platform.system() in 'Linux':
            configpath = v_report_folder + '//config'
            connectionreportpath = v_report_folder + '//report//connectiondetails.txt'
            servicereportpath = v_report_folder + '//report//serviceslist.txt'
            v_pmrep_path = v_infa_home + '//server//bin'
            v_isp_path = v_infa_home + '//isp//bin'
            v_pcversionoutputfile = v_report_folder + '//report//PcVersionDetails.txt'

        if v_check == "1" or v_check == "all":
            print("\n\nPerforming Check #1 - OS Compatibility : Started")
            checkosversion(v_report_folder)
            print("Check # 1 - OS Compatibility : Completed\n\n")

        if v_check == "2" or v_check == "all":
            while True:
                v_repodb = input("""REPO DB Version : 
                        1. press 1 for Oracle
                        2. press 2 for PostgreSQL
                        3. press 3 for SQLServer
                        : """)
                if v_repodb in ("1", "2", "3"):
                    break
                else:
                    print("Please enter valid input")

            if int(v_repodb) == 1:
                print("\n\nPerforming Check #2 - DB Compatibility : Started")
                print("checking Oracle DB version compatibility ...")
                check_oracle_version(v_report_folder)

            elif int(v_repodb) == 2:
                print("\n\nPerforming Check #2 - DB Compatibility : Started")
                print("checking PostgreSQL DB version compatibility ...")
                check_postgresql_version(v_report_folder)
            else:
                print("\n\nPerforming Check #2 - DB Compatibility : Started")
                print("checking MSSQLServer DB version compatibility ...")
                check_mssqlserver_version(v_report_folder)

        '''
        configpath = v_report_folder + '\\config'
        connectionreportpath = v_report_folder + '\\report\\connectiondetails.txt'
        v_pmrep_path = v_infa_home + '\\server\\bin'
        '''

        if v_check == "3" or v_check == "all":
            print("\n\nPerforming Check #3 - Services available on the Domain : Started")
            getservicelist(configpath, v_isp_path, v_domain, v_adminusername, v_adminpassword, servicereportpath)
            getservicedetailsfromfile(v_report_folder, servicereportpath)

        if v_check == "4" or v_check == "all":
            print("\n\nPerforming Check #4 - Connections Compatibility with CDI-PC : Started")
            getrepoconnection(configpath, v_pmrep_path, v_repository, v_domain, v_adminusername, v_adminpassword,
                              connectionreportpath)
            process_file(v_report_folder, connectionreportpath)

        if v_check == "5" or v_check == "all":
            print("\n\nPerforming Check #5 - PC Version Compatibility with CDI-PC : Started")
            getPCVersion(configpath, v_pmrep_path, v_repository, v_domain, v_adminusername, v_adminpassword,
                         v_pcversionoutputfile)
            Read_PC_Versionfile(v_report_folder, v_pcversionoutputfile)

        if v_check == "6" or v_check == "all":
            print("\n\nPerforming Check #6 - ODBC file updates : Started")
            check_odbc_ini(v_report_folder, v_infa_home)

        '''
        #v_pmrep_path = v_infa_home + '\\server\\bin\\pmrep.exe'
        #v_infacmd_path = v_infa_home + '\\isp\\bin\\infacmd.bat'
        
        if checkdir(v_infa_home):
            print('INFA Home folder present')

        if checkfile(v_pmrep_path):
            print('pmrep file exists')

        if checkfile(v_infacmd_path):
            print('infacmd file exists')
        '''
    elif int(v_input) == 2:

        licensecheck(v_report_folder)

    input("\nPress enter to exit ... ")
