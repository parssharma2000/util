import subprocess
import os
import platform

def getrepoconnection(input_ScriptPath, input_PMREPPATH, input_REPO, input_DOMAIN, input_USERNAME, input_PASSWORD, input_OUTPUTFILE):
    try:
        if platform.system() in 'Windows':
            command = input_ScriptPath + '\\' + 'getrepoconnectiondetails.bat' +' '+ input_PMREPPATH +' '+ input_REPO +' '+ input_DOMAIN +' '+ input_USERNAME +' '+ input_PASSWORD +' '+ input_OUTPUTFILE
            #print(command)
            os.system(command)
        if platform.system() in 'Linux':
            command = input_ScriptPath + '//' + 'getrepoconnectiondetails.sh' + ' ' + input_PMREPPATH + ' ' + input_REPO + ' ' + input_DOMAIN + ' ' + input_USERNAME + ' ' + input_PASSWORD + ' ' + input_OUTPUTFILE
            # print(command)
            os.system(command)

    except Exception as error:
        print("Unable to execute script")
        print("Error : ", error)

def getPCVersion(input_ScriptPath, input_PMREPPATH, input_REPO, input_DOMAIN, input_USERNAME, input_PASSWORD, input_OUTPUTFILE):
    try:
        if platform.system() in 'Windows':
            command = input_ScriptPath + '\\' + 'getPCverison.bat' +' '+ input_PMREPPATH +' '+ input_REPO +' '+ input_DOMAIN +' '+ input_USERNAME +' '+ input_PASSWORD +' '+ input_OUTPUTFILE
            #print(command)
            os.system(command)
        if platform.system() in 'Linux':
            command = input_ScriptPath + '//' + 'getPCverison.sh' + ' ' + input_PMREPPATH + ' ' + input_REPO + ' ' + input_DOMAIN + ' ' + input_USERNAME + ' ' + input_PASSWORD + ' ' + input_OUTPUTFILE
            # print(command)
            os.system(command)

    except Exception as error:
        print("Unable to execute script")
        print("Error:", error)

def getservicelist(input_ScriptPath, input_ISPPATH, input_DOMAIN, input_USERNAME, input_PASSWORD, input_OUTPUTFILE):

    if platform.system() in 'Windows':
        try:
            command = input_ScriptPath + '\\' + 'getServicesList.bat' +' '+ input_ISPPATH +' '+ input_DOMAIN +' '+ input_USERNAME +' '+ input_PASSWORD + ' ' + input_OUTPUTFILE
            #print(command)
            os.system(command)
        except Exception as error:
            print("Unable to execute script")
            print("Error:", error)

    if platform.system() in 'Linux':
        try:
            command = input_ScriptPath + '//' + 'getServicesList.sh' + ' ' + input_ISPPATH +' '+ input_DOMAIN + ' ' + input_USERNAME + ' ' + input_PASSWORD + ' ' + input_OUTPUTFILE+' >nul'
            # print(command)
            os.system(command)
        except Exception as error:
            print("Unable to execute script")
            print("Error:", error)

def getservicestatus(mydict):
    pass

if __name__ == '__main__':
    getrepoconnection(input_ScriptPath, input_PMREPPATH, input_REPO, input_DOMAIN, input_USERNAME, input_PASSWORD, input_OUTPUTFILE)

#os.system("C:\\Users\\parsharma\\testbat\\testpmrep.bat")



#v_infahome = input("Enter the Informatica home path ?")

#cmd1 = "cd C:\\Informatica\\10.5.3Server\\server\\bin\\ && pmrep connect -r repotest -d Domain -n Administrator -x Administrator && pmrep listconnections -t > C:\\Users\\parsharma\\testfolder\\abc.txt"
#abc = str(os.system(cmd1))
#print("hello")
#print(abc)
#os.system("connect -r repotest -d Domain -n Administrator -x Administrator")
#os.system("listconnections -t")

'''
version_details = str(subprocess.check_output('C:\\Informatica\\10.5.3Server\\isp\\bin\\infacmd.bat isp ListServices -dn Domain -un Administrator -pd Administrator', shell=True))
abc = version_details.replace('\\r\\n',',').replace(',Command ran successfully.,','')[2:-1:]

for servicename in abc.split(','):
    command2 = 'C:\\Informatica\\10.5.3Server\\isp\\bin\\'+'infacmd.bat'+' GetServiceStatus -dn Domain -un Administrator -pd Administrator -sn '+servicename
    version_details = str(subprocess.check_output(command2, shell=True))
    status = version_details.replace('\\r\\n',',').replace(',Command ran successfully.,','')[2:-1:]
    print(f"Service Name:{servicename} , Status: {status}")

'''

#command3 = 'C:\\Informatica\\10.5.3Server\\server\\bin\\pmrep;pmrep connect -r repotest -d Domain -n Administrator -x Administrator;pmrep listconnections -t;exit'

#command3 = 'C:\\Informatica\\10.5.3Server\\server\\bin\\pmrep'
#print(command3)
#vd = str(subprocess.check_output(command3, shell=True))



'''
command3 = ' pmrep listconnections -t'
vd = str(subprocess.check_output(command3, shell=True))
#print(version_details)
'''

'''
import os
v_output=os.system('"C:\\Informatica\\10.5.3Server\\isp\\bin\\infacmd.bat isp ListServices -dn Domain -un Administrator -pd Administrator"')
print(v_output)
v_output=os.system('"C:\\Informatica\\10.5.3Server\\isp\\bin\\infacmd.bat GetServiceStatus -dn Domain -un Administrator -pd Administrator -sn repotest"')
print(v_output)
'''