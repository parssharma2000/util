import pyodbc
import re
import config
# import getpass
import platform

def check_mssqlserver_version(v_report_folder):

    if platform.system() in 'Windows':
        v_MSSQLServer_error_folder = v_report_folder + '\\report'
        filename_op = v_MSSQLServer_error_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    if platform.system() in 'Linux':
        v_MSSQLServer_error_folder = v_report_folder + '//report'
        filename_op = v_MSSQLServer_error_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    my_file.write("Check #2 - DB Compatibility :\n\n")

    v_max_login_attempts = 2
    counter = 0
    while True:
        if counter == v_max_login_attempts:
            print("\nAttempts exhausted, please try after sometime...")
            break

        remaining_attempts = v_max_login_attempts - counter

        print(f'\nPlease enter the DB details (Attempts remaining : {remaining_attempts})...')

        server = input("Enter the SQL Server hostname or IP address : ")  # "INWPF3LZE0R\SQLEXPRESS"
        port = input("Enter the DB port number : ") # "1433"
        database = input("Enter the database name : ")  # "test_db"
        username = input("Enter the username : ")  # "Administrator"
        password = input("Enter the password : ")  # "Administrator"
        # password = getpass.getpass("Enter the password: ")  # "Administrator"
        # print(password)
        driver_no = input("Enter the ODBC driver version (Ex: 11, 13, 17, 18) : ")  # "17"
        driver = f"ODBC Driver {driver_no} for SQL Server"

        counter = counter + 1

        try:
            conn = pyodbc.connect(
                f'DRIVER={driver};'
                f'SERVER={server},{port};'
                f'DATABASE={database};'
                f'UID={username};'
                f'PWD={password}'
            )
            cursor = conn.cursor()
            cursor.execute('SELECT @@version')
            row = cursor.fetchone()

            if row:
                version = row[0]
            else:
                version = None

            version_is_compatible = True

            if version:
                match = re.search(r'Microsoft SQL Server (\d{4})', version)
                year = match.group(1)
                result = [year]
                for i in result:
                    if i not in config.mssqlserver_version:
                        print(f"MS SQL Server version {i} is not supported")
                        my_file.write(f"MS SQL Server version {i} is not supported\n\n")
                        version_is_compatible = False
                if version_is_compatible:
                    print(f"MS SQL Server version {year} is supported")
                    my_file.write(f"MS SQL Server version {year} is supported\n\n")
                    return
            else:
                print("Failed to retrieve the SQL Server version")
                my_file.write("Failed to retrieve the SQL Server version\n\n")

        except Exception as error:
                print(f"\nError connecting to SQL Server")
                print(f"\nError message: {error}")
                my_file.write(f"Error connecting to SQL Server\n")
                my_file.write(f"\nError message: {str(error)}\n\n")
                # return None

        finally:
            if 'conn' in locals():
                conn.close()

    my_file.close()

if __name__ == '__main__':
    check_mssqlserver_version(v_report_folder)