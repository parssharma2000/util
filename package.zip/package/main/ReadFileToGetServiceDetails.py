import re
import platform

def getservicedetailsfromfile(configpath, reportpath1):

    if platform.system() in 'Windows':
        v_connection_error_folder = configpath + '\\report'

        filename_op = v_connection_error_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    if platform.system() in 'Linux':
        v_connection_error_folder = configpath + '//report'

        filename_op = v_connection_error_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    # my_file.write("Check #3 - Services enabled/disabled on the Domain :\n\n")
    my_file.write("Check #3 - Services available on the Domain :\n\n")

    file1 = open(reportpath1, 'r')
    Lines = file1.readlines()
    my_dict = {}
    list =[]
    flag =0
    # Strips the newline character
    for line in Lines:

        if (not ((bool(re.search(" failed with error", line.strip()))))) :

            if (line.strip() not in ('"Starting infacmd..."','Command ran successfully.') ):

                if flag == 1 and not (bool(re.search("service details :", line.strip()))):
                     list.append(line.strip())

                if (bool(re.search("service details : START", line.strip()))):
                    servicename=line.strip()[0:2]
                    flag = 1
                    #print(servicename)

                if (bool(re.search("service details : END", line.strip()))):
                    if list !=[]:
                        my_dict[servicename] = list
                        list = []
                        flag = 0

        else:
            flag = 0
            list = []
            #print("in else",line.strip())


    print(my_dict.items())
    my_file.write(f"{my_dict.items()}\n\n")

    my_file.close()

