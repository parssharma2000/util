import requests
import json
from getpass import getpass
import maskpass
import platform

def licensecheck(v_report_folder):
    if platform.system() in 'Windows':
        v_license_folder = v_report_folder + '\\report'

        filename_op = v_license_folder + '\\' + 'License_Output_Report_File.txt'
        my_file = open(filename_op, 'w+')

    if platform.system() in 'Linux':
        v_license_folder = v_report_folder + '//report'

        filename_op = v_license_folder + '//' + 'License_Output_Report_File.txt'
        my_file = open(filename_op, 'w+')

    my_file.write("Check #1 - Required License availability : \n\n")

    correct_inp_flag = False
    no_of_attempts = 0
    Required_Licenses = ["Domain Management Service",
                         "DomainManagementApp",
                         "PC2CDI Assessment",
                         "PC2CDIModernizationApp",
                         "PC2CDI Modernization Service",
                         "DVProcessor",
                         "Data Validation"]
    present = []

    while correct_inp_flag == False:
        # URL endpoint
        # url = "https://dmr-us.informaticacloud.com/ma/api/v2/user/login"
        login_url = input("Enter the IDMC login url : ")
        url = login_url + "api/v2/user/login"
        url = url.replace('home', "")
        # print(url)
        username = input("Enter the IDMC username : ")
        # password=getpass("Enter the IDMC password: ")
        password = maskpass.askpass(prompt="Enter the IDMC password (Type it): ", mask="#")

        # JSON payload
        payload = {
            "username": username,
            "password": password
        }

        # Headers
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        try:
            # Making POST request
            response = requests.post(url, json=payload, headers=headers)

            # Check response status
            if response.status_code == 200:
                # Successful request
                print("Login API request successful!")
                correct_inp_flag = True
                # Access response data
                # print("Response JSON:")

                # Print each key-value pair of the JSON response
                # for key, value in response.json().items():
                # print(f"{key}: {value}")
            else:
                # Request failed
                print("Login failed with status code:", response.status_code)
                my_file.write(f"Login failed with status code : {response.status_code}\n\n")
                print("Response content:", response.text)
                my_file.write(f"Response content : {response.text}\n\n")
                no_of_attempts = no_of_attempts + 1
                if no_of_attempts >= 3:
                    print("Refusing to connect. Please try after sometime or check the credentials")
                    break
        except Exception as e:
            print("The Login request failed, please check the credentials and try again! Error message:", e)
            my_file.write(f"The Login request failed, please check the credentials and try again! Error message : {e}\n\n")
            no_of_attempts = no_of_attempts + 1
            if no_of_attempts >= 3:
                print("Refusing to connect. Please try after sometime or check the credentials")
                break

    if no_of_attempts < 3:

        # Extract session information
        session_id = response.json()['icSessionId']
        server_url = response.json()['serverUrl']
        org_id = response.json()['orgUuid']

        # Construct URL for GET request
        url = server_url + "/license-service/api/v1/OrgLicenseAssignment('" + org_id + "')/View()"
        url = url.replace('/saas', "")
        # print(url)

        # Headers for GET request
        headers1 = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "IDS-SESSION-ID": session_id
        }
        try:
            # Making GET request
            response = requests.get(url, headers=headers1)

            # Check response status
            if response.status_code == 200:
                # Successful request
                print("License API request successful!")

                # Access response data
                # print("Response JSON:")
                # print("Response content:", response.text)
                # Print each key-value pair of the JSON response
                # print("abc")
                # print(type(response))
                # res=json.dumps(response.json(),indent=3)
                # print(res)
                parsed_json = json.loads(response.text)
                # print(parsed_json)
                assignedEditions = [item["name"] for item in parsed_json["assignedEditions"]]
                # print(assignedEditions)
                assignedConnectorLicenses = [item["name"] for item in parsed_json["assignedConnectorLicenses"]]
                # print(assignedConnectorLicenses)
                assignedCustomLicenses = [item["name"] for item in parsed_json["assignedCustomLicenses"]]
                # print(assignedCustomLicenses)

                for i in assignedEditions:
                    if i in Required_Licenses:
                        present.append(i)
                for i in assignedConnectorLicenses:
                    if i in Required_Licenses:
                        present.append(i)
                for i in assignedCustomLicenses:
                    if i in Required_Licenses:
                        present.append(i)
                for i in Required_Licenses:
                    if i not in present:
                        print(f" {i} is not available")
                        my_file.write(f" {i} is not available\n\n")
                        # print("Required licenses are missing")
                    else:
                        print(f" {i} is available")
                        my_file.write(f" {i} is available\n\n")


            else:
                # Request failed
                print("GET request failed with status code:", response.status_code)
                my_file.write(f"GET request failed with status code : {response.status_code}\n\n")
                res = json.dumps(response.json(), indent=3)
                print(res)
        except Exception as e:
            print("License API request failed. :", e)
            my_file.write(f"License API request failed : {e}\n\n")

    my_file.close()