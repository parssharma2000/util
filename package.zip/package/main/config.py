#######################################################
#### Configuration file , PAM
#### Date : 20 March 2024
########################################################

supported_os = ['Windows', 'Red Hat Enterprise Linux', 'SUSE Linux', 'Amazon Linux']
rhel_supported_version = ['8.1', '8.2', '8.3', '8.4', '8.5', '8.6', '8.7', '8.8', '8.9']
windows_supported_version = ['14393', '16299', '17134', '17763', '18362', '18363', '19041', '19042', '20348','19045']
suse_linux_version = ['12.5', '15.2', '15.3', '15.4', '15.5']
amazon_linux_version = ['2.0.20231101.0']
oracle_version = ['Oracle Database 19c', 'Oracle Database 21c', 'Oracle Database 18c', 'Oracle Database 12c']
mssqlserver_version = ['2017', '2019']
supported_postgre_versions=[14.3, 13.4, 12.3]
supported_relational_connections = ['Oracle', 'Sybase', 'Informix (Obsolete)', 'Microsoft SQL Server', 'DB2', 'ODBC',
                                    'Teradata', 'NEOVIEW', 'Netezza', 'Vertica', 'PowerChannel for DB2',
                                    'PowerChannel for Oracle', 'PowerChannel for MS SQL Server',
                                    'PowerChannel for ODBC', 'PWX DB2zOS', 'PWX DB2i5OS', 'PWX DB2LUW', 'PWX Oracle',
                                    'PWX MSSQLServer', 'PWX NRDB Lookup', 'Teradata PT Connection Deprecated',
                                    'Teradata PT Connection']
supported_app_connections = ['SAP BW', 'SAP R3', 'SAP ABAP HTTP Streaming', 'PeopleSoft Oracle', 'PeopleSoft Sybase',
                             'PeopleSoft Informix', 'PeopleSoft MsSqlserver', 'PeopleSoft Db2', 'Siebel Oracle',
                             'Siebel Sybase', 'Siebel Informix', 'Siebel MsSqlserver', 'Siebel Db2',
                             'SAP_ALE_IDoc_Reader', 'SAP TYPE A', 'SAP_BWOHS_READER', 'SAP_ALE_IDoc_Writer',
                             'SAP RFC/BAPI Interface', 'JNDI Connection', 'JMS Connection', 'webMethods Broker',
                             'webMethods Integration Server', 'Web Services Consumer', 'PWX NRDB Batch',
                             'PWX NRDB CDC Change', 'PWX NRDB CDC Real Time', 'PWX DB2zOS CDC Change',
                             'PWX DB2zOS CDC Real Time', 'PWX DB2i5OS CDC Change', 'PWX DB2i5OS CDC Real Time',
                             'Http Transformation', 'PWX Orade CDC Change', 'PWX Orade CDC Real Time', 'LMAPITarget',
                             'Teradata FastExport Connection', 'PWX MYSQL CDC Change', 'PWX MYSQL CDC Real Time',
                             'PWX DB2LUW CDC Change', 'PWX DB2LUW CDC Real Time', 'PWX PostgreSQL CDC Change',
                             'PWX PostgreSQL CDC Real Time', 'PWX SAP HANA CDC Change', 'PWX SAP HANA CDC Real Time',
                             'Salesforce Connection', 'Hadoop HDFS Connection']
Supported_PC_Version=['10.4.0', '10.4.1', '10.5', '10.5.1', '10.5.2', '10.5.3']