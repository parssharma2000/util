import time
import psycopg2
import getpass
from psycopg2.extras import RealDictCursor
import re
from config import supported_postgre_versions
import platform

def check_postgresql_version(v_report_folder):

    if platform.system() in 'Windows':
        v_PostgreSQL_error_folder = v_report_folder + '\\report'

        filename_op = v_PostgreSQL_error_folder + '\\' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    if platform.system() in 'Linux':
        v_PostgreSQL_error_folder = v_report_folder + '//report'

        filename_op = v_PostgreSQL_error_folder + '//' + 'Output_Report_File.txt'
        my_file = open(filename_op, 'a+')

    my_file.write("Check #2 - DB Compatibility :\n\n")

    failure_attempt_count = 0

    while True:
        if failure_attempt_count > 1:
            #print('Please verify the Database details you are trying enter, otherwise Database user will get locked')
            #time.sleep(1)
            print("Incorrect DB details... ")
            my_file.write("Incorrect DB details... \n\n")
            break
        try:
            #conn = psycopg2.connect(host='localhost', database='db', user='usr', password='usr', port=5433)
            #schema_name = "s1"
            conn = psycopg2.connect(host=input('Enter DataBase HostName : '), database=input('Enter DataBase Name : '),
                                user=input('Enter DataBase UserName : '), password=input('Enter DataBase Password : '),
                                port=input('Enter Port Number : '))
            schema_name = input('Enter Schema name, press enter to connect with public schema (case sensitive) : ') or 'public'
            cursor = conn.cursor()

            try:
                cur = conn.cursor()
                cur.execute("SELECT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = %s)",
                        (schema_name,))
                exists = cur.fetchone()[0]
                cur.close()
                Result = exists
            except Exception as e:
                print("Error checking schema existence : ", e)
                my_file.write(f"Error checking schema existence : {e}\n\n")
                Result = False

            if Result:
                cursor.execute(f"SET search_path TO '{schema_name}';")
                conn.commit()

                cursor.execute("SELECT version();")
                version = cursor.fetchone()[0]
                print(f"Connected to '{schema_name}' schema successfully.")
                print("PostgreSQL version : ", version)

                version_number = version.split(',')[0]
                # print(version_number)
                match = re.search(r'PostgreSQL (\d{2})\.(\d{1})', version_number)
                only_number = match.group(1) + '.' + match.group(2)
                # print(only_number)
                # print(supported_postgre_versions)
                if only_number in supported_postgre_versions:
                    print(f"{version_number} is Supported for CDI-PC migration process")
                    my_file.write(f"{version_number} is Supported for CDI-PC migration process\n\n")
                else:
                    print('CDI-PC Migration is only supported for PostgreSQL DB versions : ', supported_postgre_versions)
                    my_file.write(f'CDI-PC Migration is only supported for PostgreSQL DB versions : {supported_postgre_versions}\n\n')
                    print(f"{version_number} is Not Supported for CDI-PC migration process")
                    my_file.write(f"{version_number} is Not Supported for CDI-PC migration process\n\n")

                break
            else:
                print(f"The schema '{schema_name}' does not exist.")
                my_file.write(f"The schema '{schema_name}' does not exist\n\n")
                failure_attempt_count = failure_attempt_count + 1
                time.sleep(1)

        except psycopg2.Error as e:
            print("Error connecting to the PostgreSQL database : ", e)
            my_file.write(f"Error connecting to the PostgreSQL database : {e}\n\n")
            failure_attempt_count = failure_attempt_count + 1

    my_file.close()

if __name__ == '__main__':
    check_postgresql_version(v_report_folder)